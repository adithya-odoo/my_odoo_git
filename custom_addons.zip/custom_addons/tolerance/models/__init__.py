# -*- coding: utf-8 -*-

from . import purchase_order_line
from . import res_partner
from . import sale_order_line
from . import stock_picking
from . import warning_wizard