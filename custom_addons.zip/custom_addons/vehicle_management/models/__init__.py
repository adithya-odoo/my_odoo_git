# -*- coding: utf-8 -*-

from . import repair_tag
from . import vehicle_customer
from . import vehicle_date_report
from . import vehicle_employee
from . import vehicle_management
from . import vehicle_product

