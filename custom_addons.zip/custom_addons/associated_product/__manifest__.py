# -*- coding: utf-8 -*-

{
    'name' : 'Associated Product',
    'version': '17.0.1.0.0',

    'depends': [
        'base',
        'sale_management',
        'hr',
    ],

    'data': [
        'views/res_partner.xml',
        'views/sale_order.xml',
    ],

    'license': 'LGPL-3',
}