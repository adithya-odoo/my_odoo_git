# -*- coding: utf-8 -*-

{
    'name': "Manufacturing Task",
    'version': '17.0.1.0.0',
    'application': True,

    'depends': [
        'base',
        'mrp',
    ],

    'data' : [
           'views/manufacturing_cost.xml',
    ]
}