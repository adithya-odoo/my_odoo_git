/** @odoo-module */
import { ErrorPopup } from "@point_of_sale/app/errors/popups/error_popup";
import { _t } from "@web/core/l10n/translation";
import { patch } from "@web/core/utils/patch";
import { Order,  Orderline } from "@point_of_sale/app/store/models";

patch(Order.prototype, {
async pay() {
   if((this.pos.config.discount_limit && this.get_total_discount()) || (this.pos.config.discount_limit_percentage && this.get_total_discount())){
       if(this.pos.config.type == 'amount'){
            var total_discount_pos = await this.env.services.orm.call('pos.order','return_total_discount_pos',
                                                   [this.pos_session_id])
            var set_discount_limit = this.pos.config.discount_limit
            console.log(this.pos.config)
             console.log(this.pos.config.type)
             if (this.get_total_discount() > set_discount_limit || (total_discount_pos+this.get_total_discount()) > set_discount_limit){
                   this.env.services.popup.add(ErrorPopup, {
                    title: _t("Alert"),
                    body: _t('Discount limit for the current session is exceeded'),
                  });
             }
             else {
                  return {
                     ...super.pay(...arguments),
                         };
                  }
       }
       else if(this.pos.config.type == 'percentage'){
         var order_lines = this.get_orderlines();
         var total_without_discount = 0;
         order_lines.forEach(function(line) {
         var line_price_without_discount = line.get_unit_price() * line.get_quantity();
         total_without_discount += line_price_without_discount;
         });
//          var whole_discount = 0
//          console.log(this.get_total_with_tax(), this.get_total_discount()  )
//          console.log(this.pos.config.discount_limit_percentage * 100)
//       this.orderlines.forEach(function(line){
//        whole_discount = whole_discount + line.get_discount();
//        return whole_discount
//         });
//       console.log(whole_discount, "djwhgw")
//          var discount_percentage = (this.get_total_discount() / this.get_total_with_tax())*100
//           let discount_percentage_amount = 0
//              discount_percentage_amount = discount_percentage_amount + discount_percentage
////
          console.log(total_without_discount, this.orderlines.get_price_with_tax_before_discount(), "nooooooooo")
//          console.log(this.get_total_discount(),"weuygdyu")
//          if(this.pos.config.discount_limit_percentage * 100 < whole_discount){
//            this.env.services.popup.add(ErrorPopup, {
//                    title: _t("Alert"),
//                    body: _t('Discount limit percentage for the current session is exceeded'),
//                  });
          }
//          else{
//          return {
//                  ...super.pay(...arguments),
//                  };
//         }

       }

   else {
       return {
           ...super.pay(...arguments),
        };
       }
   },
});



